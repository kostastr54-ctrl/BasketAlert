# BasketAlert PWA

Έτοιμη web/PWA έκδοση του BasketAlert. Ανεβαίνει σε οποιοδήποτε HTTPS hosting και μετά στο iPhone:
Safari → Share → Add to Home Screen.

Σημείωση: τα πραγματικά push notifications στο iOS web απαιτούν κατάλληλο HTTPS/PWA setup και web push υποδομή. Η τρέχουσα έκδοση περιέχει δοκιμή ειδοποίησης και demo live αγώνες.
